'use strict';

/**
 * order-world router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::order-world.order-world');
