'use strict';

/**
 * order-ukraine service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::order-ukraine.order-ukraine');
