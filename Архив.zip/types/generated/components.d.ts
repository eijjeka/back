import type { Schema, Attribute } from '@strapi/strapi';

declare module '@strapi/types' {
  export module Shared {}
}
